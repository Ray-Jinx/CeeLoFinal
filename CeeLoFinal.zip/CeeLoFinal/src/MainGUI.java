
public class MainGUI {
	public static void main(String[] args) {
		
		LaunchPage launchPage = new LaunchPage();
		
	}
}
